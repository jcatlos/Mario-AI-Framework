#!/bin/sh
java -jar Mario-AI-Framework.jar